#!/bin/sh
DIRNAME=`dirname $0`
java -Xmx512m -classpath $DIRNAME/dist/kr.jar kr/gui/KRViewerTest $*

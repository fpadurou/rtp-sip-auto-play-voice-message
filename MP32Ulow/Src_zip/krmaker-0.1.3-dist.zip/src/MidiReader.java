import jm.music.data.Score;
import jm.util.Read;
import jm.util.View;

public class MidiReader {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Score theScore = new Score("Temporary score");
		// read the MIDI files made earlier as input
		Read.midi(theScore, args[0]);

		View.show(theScore);
	}

}

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class KRTest {
	public static void main(String [] argv) throws Exception
	{
		
		StringBuffer sb = new StringBuffer();
		for(int i = 0; i < 55306; i++)
		{
			sb.append((char)(i % 65 + 'a'));
		}
		
		ZipOutputStream zo = new ZipOutputStream(new FileOutputStream("test.zip"));
		for(int i = 0; i < 10; i++)
		{
		zo.putNextEntry(new ZipEntry("foo"));
		OutputStream o2 = new FileOutputStream("foo2");

		byte [] data = new byte[4096];
		for(int i = 0; i < 4096; i++)
		{
			data[i] = (byte) ('a' + i % 26);
		}
		
		int i = 0;

		for(i = 0; i + 4096 < 55306; i+= 4096)
		{
			zo.write(data);
			o2.write(data);
		}
		
		zo.write(data, 0, 55306 - i );
		zo.close();

		o2.write(data, 0, 55306 - i );
		o2.close();
	}
	
}

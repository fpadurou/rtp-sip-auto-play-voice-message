package kr.gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.sound.midi.Track;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import kr.AudioChannelModel;

//NOTE: this is not currently used. calibration doesn't appear to be needed using the new half and 3/4 speed slowdown technique.
// Also note that it is slightly broken. The notes displayed do not come at the right time.
public class KRCalibrateWindow extends JFrame
{
	private GuiModel guiModel;
	AudioGraph graph;
	JButton finish;
	JLabel calibration;

	public KRCalibrateWindow(GuiModel guiModel, KRCalibrationWindowController cont)
	{
		this.guiModel = guiModel;
		
		init();
		
		cont.init(this, guiModel);
	}
	
	private void init()
	{
		//content.removeAll();
		setTitle("KR Maker Calibration");
		
		Container content = getContentPane();
		
        content.setLayout(new GridBagLayout());


        GridBagConstraints c = new GridBagConstraints();
        c.weightx = 1; c.weighty = .1;
        c.fill = c.BOTH;
        c.gridx=c.gridy=0;
        c.gridwidth=2;c.gridheight=1;
//        c.insets = new Insets(3,3,3,3); 
        
        JLabel t = new JLabel("<html>Hit the 'b' key in time with the start of each note. " +
        		"If correctly calibrated, each wave should cross" +
        		" the gray line exactly when the beat plays</html>");
        content.add(t,c);
        
        c.gridy++;
        c.weightx = c.weighty = 1;
        c.fill = c.BOTH;
         
        content.add(graph = new AudioGraph(guiModel, new AudioChannelModel()), c);
        graph.setEnabled(false);
        
        c.gridy++;
        c.gridwidth=1;c.gridheight=1;
        c.weightx = c.weighty = 0;
        c.fill = c.BOTH;
         
        content.add(new JLabel("Calibration: "), c);

        c.gridwidth=1;c.gridheight=1;
        c.gridx++;
        c.weightx = 1; c.weighty = 0;
        c.fill = c.NONE;
        c.anchor = c.WEST;
         
        content.add(calibration = new JLabel(""), c);
        
        c.gridx = 0;
        c.gridwidth=2;c.gridheight=1;
        c.gridy ++;
        c.weightx = 0; c.weighty = 0;
        c.fill = c.NONE;
        c.anchor = c.CENTER;
        
        content.add(finish = new JButton("Finish"),c);
        
        setBounds(getX(), getY(), 400, 300);
        setVisible(true);
	}
}

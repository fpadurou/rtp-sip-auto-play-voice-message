package kr.gui.util;

import java.awt.Component;

public interface UIMode {
	
	public void start(Component comp);
	
	public void stop(Component comp);

}

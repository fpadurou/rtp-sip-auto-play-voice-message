package kr.gui.util;

import java.awt.Component;

import javax.swing.event.MouseInputAdapter;

public class MouseInputUIMode extends MouseInputAdapter implements UIMode
{

	public void start(Component comp) {
		comp.addMouseListener(this);
		comp.addMouseMotionListener(this);		
	}

	public void stop(Component comp) {
		comp.removeMouseListener(this);
		comp.removeMouseMotionListener(this);		
	}

}

package kr.gui.util;

import java.awt.Component;

/**
 * Does not respond to anything
 */
public class FrozenUIMode implements UIMode {

	public void start(Component comp) {
	}

	public void stop(Component comp) {
	}

}

package kr.gui.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import kr.util.ListenerManager;

public class SimplePopupMenu extends JPopupMenu implements ActionListener
{
	public enum Type { ITEM_CHOSEN };
	
	public SimplePopupMenu()
	{
	}
	
	public JMenuItem add(String s)
	{
		JMenuItem i = super.add(s);
		i.addActionListener(this);
		
		return i;
	}

	public void actionPerformed(ActionEvent e) {
		ListenerManager.inst().notify(this, Type.ITEM_CHOSEN, ((JMenuItem)e.getSource()).getText());
	}
	
}

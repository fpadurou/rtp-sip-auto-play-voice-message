package kr.gui;

import javax.swing.SwingUtilities;

public class GuiUtils {

	public static void invokeInNonAwtThread(Runnable r) {
		if(SwingUtilities.isEventDispatchThread())
			new Thread(r).start();
		else r.run();
	}

}

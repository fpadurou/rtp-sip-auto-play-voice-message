//package kr.gui;
//
//import java.io.IOException;
//import java.util.List;
//
//import javax.sound.midi.InvalidMidiDataException;
//import javax.sound.midi.MidiSystem;
//import javax.sound.midi.MidiUnavailableException;
//import javax.sound.midi.Receiver;
//import javax.sound.midi.ShortMessage;
//import javax.sound.midi.Synthesizer;
//import javax.sound.sampled.AudioFormat;
//import javax.sound.sampled.AudioInputStream;
//import javax.sound.sampled.AudioSystem;
//import javax.sound.sampled.DataLine;
//import javax.sound.sampled.LineUnavailableException;
//import javax.sound.sampled.SourceDataLine;
//import javax.sound.sampled.AudioFormat.Encoding;
//
//import kr.AudioModel;
//import kr.FileModel;
//import kr.MidiTuneModel;
//import kr.TimeKeeper;
//import kr.util.Listener;
//import kr.util.ListenerManager;
//import kr.util.audio.AudioClip;
//import kr.util.audio.MidiAudioClip;
//
///**
// * Plays notes in as close to real time as possible.
// */
////NOT USED!!!!!!!!!!!!!!!!
//public class RealTimeNotePlayController extends AudioPlayController implements Runnable, Listener
//{
//	private GuiModel guiModel;
//	private MidiAudioClip midiAudioClip;
//	private byte note = -1;
//	private double cycleSize;
//	private double correctAmount;
//	
//	public RealTimeNotePlayController()
//	{
//		midiAudioClip = new MidiAudioClip(48000);
//		super.setAudioOut(midiAudioClip);
//	}
//	
//	public void init(GuiModel guiModel)
//	{
//		this.guiModel = guiModel;
//		ListenerManager.inst().registerListener(guiModel, this);
//		if(!guiModel.isPlaying())
//			new Thread(this).start();
//	}
//
//	public void notify(Object source, Object type, Object... values) {
//		if ((GuiModel.MessageType) type == GuiModel.MessageType.IS_PLAYING_UPDATED) {
//			if (guiModel.isPlaying()) //if we're playing the song, stop our thread 
//			{
//				//stop();
//			}
//			else //if we stopped playing the song, enable our thread
//			{
//				//new Thread(this).start();
//			}
//		}
//		else if ((GuiModel.MessageType) type == GuiModel.MessageType.REAL_TIME_NOTE_UPDATED) {
//			playNote(guiModel.getNote());
//		}
//	}
//	
//	public void playNote(byte note)
//	{
//		synchronized(this)
//		{
//			this.note = note;
//			midiAudioClip.playMidi(note);
//			if(note != -1)
//				this.cycleSize = midiAudioClip.getCycleBytesForNote(note);
//			setCurPos(0);
//			correctAmount = 0;
//		}
//	}
//	
//	public int getWriteBufferSize()
//	{
//		synchronized(this) {
//			if(note == -1) return MAX_WRITE_BUFFER_SIZE;
//			return (int)Math.round(correctAmount + cycleSize - getCurPos());
//		}
//	}
//	
//	protected void notifyBufferWrote(int size)
//	{
//		correctAmount += cycleSize;
//	}
//
//	public int getNote() {
//		return note;
//	}
//	
//}

package kr.gui.midigraph;

public abstract class UI 
{
	public UI() {
	}
}

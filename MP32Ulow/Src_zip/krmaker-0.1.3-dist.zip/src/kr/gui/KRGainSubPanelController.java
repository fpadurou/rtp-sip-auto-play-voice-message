package kr.gui;

import kr.gui.GainPanel.SubPanel;

public class KRGainSubPanelController extends GainSubPanelController
{
	public KRGainSubPanelController(GainPanel panel, SubPanel subPanel, int lineNumber)
	{
		super(panel, subPanel, lineNumber);
	}
	
}

package kr.gui;

import kr.util.audio.AudioClip;
import kr.util.audio.MidiAudioClip;

//TODO: Write this when done with main functionality
/**
 * Plays midi notes in real time but resembles an AudioClip. Does so
 * without noticable clicking when changing notes
 * (which MidiAudioClip would do).
 * Note that only reading data in a forward fashion is supported.
public class RealTimeMidiAudioClip extends AudioClip
{
	private int rate;
	private double cycleLength;
	private int lastTransistionIndex;
	
	private int note = -1;
	private int nextNote = -1;
	
	private MidiAudioClip ac = new MidiAudioClip();

	public RealTimeMidiAudioClip(int rate)
	{
		this.rate = rate;
	}

	@Override
	public int getNumChannels() {
		return 1;
	}

	@Override
	public int length() {
		return Integer.MAX_VALUE;
	}

	@Override
	public int getRate() {
		return rate;
	}

	@Override
	public byte byteAt(int index) {
		return 0;
	}

	@Override
	public void copyTo(int offset, int length, byte[] dest, int destOffset) {
		
	}

}
 */

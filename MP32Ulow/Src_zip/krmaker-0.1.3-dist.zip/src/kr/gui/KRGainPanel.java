package kr.gui;

import javax.swing.JPanel;

public class KRGainPanel extends GainPanel
{
	private GuiModel guiModel;

	public KRGainPanel(GuiModel guiModel)
	{
		this.guiModel = guiModel;
		init();
	}
	
	private void init()
	{
		super.init(guiModel.getMixer());
	}
}

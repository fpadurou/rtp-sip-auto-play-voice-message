package kr.gui;

import javax.swing.JPanel;

import kr.FileModel;

public class FilePanel extends JPanel {

	public FilePanel(FileModel fileModel, FileController fileController) {
	}

}

package kr.midireader.krwriter;


public class IMA4State
{

    public int valprev;
    public int index;
}

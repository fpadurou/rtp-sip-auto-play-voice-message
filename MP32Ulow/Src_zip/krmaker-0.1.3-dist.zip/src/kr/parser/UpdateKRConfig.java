package kr.parser;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

import kr.util.Util;

public class UpdateKRConfig {
	public static void main(String [] argv) throws Exception
	{
		if(argv.length == 0)
		{
			usageAndExit(null);
		}
		
		
		int argIndex = 0;
		
		File songsDta = null;
		File dbDta = null;
		
		boolean sortAlphaAll = false;
		boolean sortNewSongsAtEnd = true;
		
		while(argIndex < argv.length)
		{
			if(argv[argIndex].equals("-sortNewSongsInline"))
			{
				sortNewSongsAtEnd = false;
				argIndex ++;
			}
			else if(argv[argIndex].equals("-db"))
			{
				dbDta = new File(argv[argIndex+1]);
				argIndex +=2;
			}
			else if(argv[argIndex].equals("-songs"))
			{
				 songsDta = new File(argv[argIndex+1]);
 				 argIndex +=2;
			}
			else usageAndExit("Illegal argument "+argv[argIndex]);
		}
		
		if(songsDta == null && sortNewSongsAtEnd)
			usageAndExit("-songs <songs.dta file> must be specified if -sortNewSongsInline is specified");
		
		if(songsDta != null)
		{
			if(sortNewSongsAtEnd)
				System.out.println("Sorting new songs at the end");
			else
				System.out.println("Sorting new songs inline with originals");
			String songsDtaText = Util.readText(songsDta); 
			SongsDtaObject songsDtaObject = new SongsDtaObject(songsDtaText, sortNewSongsAtEnd);

			Util.writeFile(songsDta, songsDtaObject.createText());
		}
		
		if(dbDta != null)
		{
			System.out.println("Updating db.dta so that existing save can be used");

			String dbDtaText = Util.readText(dbDta);
			DbDtaFile ddf = new DbDtaFile(dbDtaText);
			ddf.updateUnlocksToMatchHighscores();
			
			Util.writeFile(dbDta, ddf.getText());
		}
	}
			
	private static void usageAndExit(String message) {
		if(message != null)
			System.err.println(message+"\n");
		System.err.println("Usage: UpdateKRConfig [-songs <songs.dta file> [-sortNewSongsInline]] [-db <db.dta file>]");
		System.err.println(" This utility updates the config files songs.dta and/or db.dta");
		System.err.println(" [-songs <songs.dta file>] - if specified, then the songs in the songs.dta file will be sorted.");
		System.err.println("    [-sortNewSongsInline] - if specified, then the new homebrew songs will be sorted inline with the" +
				" original Karoake Revolution songs. Otherwise, all the new homebrew songs will be placed at the end.");
		System.err.println(" [-db <db.dta file>] - if specified, the db.dta file will be updated so that any new homebrew songs can" +
				" be used with an old existing save file.");
		System.err.println(" To do this, after updating the db.dta file, load your existing save file and play Single Player, " +
				"Arcade Mode, Easy with Easy Judging Mode. Then choose any 3 songs and sing them all with gold or better. All the new" +
				" homebrew songs will be unlocked and playable after this.");
		System.exit(1);
		
	}


}

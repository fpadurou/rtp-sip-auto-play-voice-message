package kr.parser;

/**
 * Represents a single object to parse
 */
public interface BinaryParseObject {
	
	/**
	 * Parses a single item into this.
	 * 
	 * @param data data to parse
	 * @param start index to start looking
	 * @return index where object ends
	 */
	public int parseItem(byte [] data, int start);
	
}

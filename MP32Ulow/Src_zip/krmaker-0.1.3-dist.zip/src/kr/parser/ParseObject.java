package kr.parser;

/**
 * Represents a single object to parse
 */
public interface ParseObject {
	
	/**
	 * Parses a single item into this.
	 * 
	 * @param text text to parse
	 * @param start index to start looking
	 * @return index where object ends
	 */
	public int parseItem(String text, int start);
	
}

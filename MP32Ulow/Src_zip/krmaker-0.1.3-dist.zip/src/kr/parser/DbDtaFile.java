package kr.parser;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import kr.parser.javacc.DbDtaParser;
import kr.parser.javacc.DtaBrace;
import kr.parser.javacc.ParseException;
import kr.util.Util;

public class DbDtaFile {
        private DtaBrace file;

        public DbDtaFile(String text) throws ParseException {
                file = new DbDtaParser(new StringReader(text)).File();
        }

        /**
         * Updates unlock sections to match high score sections
         */
        public void updateUnlocksToMatchHighscores() {
                try {
                        DtaBrace hiScores = file.findBrace("hi_scores");

                        HashSet<String> songs = new HashSet<String>();

                        for (DtaBrace songBrace : hiScores.getSubBraces()) {
                                songs.add(songBrace.getName());
                        }

                        //
                        // add songs to kUnlockSong
                        //

                        HashSet<String> songsToAdd = (HashSet<String>) songs.clone();

                        // find songs already in kUnlockSong
                        DtaBrace unlockedSongs = file.findBrace("initial_unlocks")
                                        .findBrace("kUnlockSong");

                        for (String song : unlockedSongs.getIds()) {
                                songsToAdd.remove(song);
                        }

                        // add the new ones
                        for (String songToAdd : songsToAdd) {
                                unlockedSongs.addData("      " + songToAdd + "; added by krmaker\n");
                        }

                        //
                        // add songs to unlocks
                        //

                        songsToAdd = (HashSet<String>) songs.clone();

                        // find songs already in unlocks
                        DtaBrace unlocks = file.findBrace("unlocks");

                        for (DtaBrace subBrace : unlocks.getSubBraces()) {
                                if ("kRuleArcade".equals(subBrace.getName())) {
                                    songsToAdd.remove(subBrace.getId(4));
                                }
                        }
                        
                        // add the new ones
                        for (String songToAdd : songsToAdd) {
                                unlocks
                                                .addData("   (kRuleArcade   0           kRatingPassGold      kUnlockSong    "
                                                                + songToAdd + " ); added by krmaker\n");
                        }

                } catch (ParseException e) {
                	e.printStackTrace();
                    throw new IllegalStateException("Internal error "+e);
                }

        }

		public String getText() {
			return file.getInternalText();
		}
}

class DbDtaFileTest
{
        public static void main( String [] argv) throws ParseException, IOException
        {
                DbDtaFile ddf = new DbDtaFile(Util.readText(new File(argv[0])));
                ddf.updateUnlocksToMatchHighscores();
                
                System.out.println(ddf.getText());
        }
}

package kr.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import kr.util.Util;

public class DbDtaObject extends DtaObject
{
	private String dbDtaText;

	public DbDtaObject(String dbDtaText) {
		init(dbDtaText);
	}
	
	public DbDtaObject(File file) throws IOException {
		FileInputStream is = new FileInputStream(file);
		String text = Util.readText(is);
		is.close();
		
		init(text);
	}

	private void init(String dbDtaText)
	{
		parseItem(dbDtaText, 0);
		this.dbDtaText = dbDtaText;
		
		int index = 0;
		
		while(index < dbDtaText.length())
		{
			SongsDtaSong song = new SongsDtaSong();
			index = song.parseItem(dbDtaText, index);
			if(song.parsedSuccessfully())
				songs.add(song);
		}
	}

}

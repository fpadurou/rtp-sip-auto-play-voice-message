package kr.parser.javacc;

public class DtaElement {
	private Type type;
	
	private String text;

	protected static enum Type { BRACE, ID, FLOAT, STRING, COMMENT, BLANK };
	
	public DtaElement(Type type)
	{
		this.type = type;
	}

	public DtaElement(String text, Type type) {
		this.text = text;
		this.type = type;
	}

	public Type getType() {
		return type;
	}

	public String getText() {
		return text;
	}
	
}

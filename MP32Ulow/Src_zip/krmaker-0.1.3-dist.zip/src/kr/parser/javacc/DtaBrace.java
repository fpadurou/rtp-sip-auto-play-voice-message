package kr.parser.javacc;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import kr.parser.javacc.DtaElement.Type;

/**
 * Represents a "(" ... ")" in a dta file.
 */
public class DtaBrace extends DtaElement
{
	private List<DtaElement> childElements = new ArrayList<DtaElement>();
	
	public DtaBrace()
	{
		super(Type.BRACE);
	}

	public void addID(String id) {
		childElements.add(new DtaElement(id, Type.ID));
	}

	public void addString(String str) {
		childElements.add(new DtaElement(str, Type.STRING));
	}

	public void addComment(String comm) {
		childElements.add(new DtaElement(comm, Type.COMMENT));
	}

	public void addBlank(String blank) {
		childElements.add(new DtaElement(blank, Type.BLANK));
	}

	public void addFloat(String flt) {
		childElements.add(new DtaElement(flt, Type.FLOAT));
	}

	public void addSubDtaBrace(DtaBrace subDb) {
		childElements.add(subDb);
	}

	public DtaBrace findBrace(String name) {
		for(DtaElement de : childElements)
		{
			if(de.getType() == Type.BRACE)
			{
				DtaBrace db = (DtaBrace)de;
				if(name.equals(db.getName()))
					return db;
			}
		}
		
		return null;
	}
		
	public String getText()
	{
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		sb.append(getInternalText());
		sb.append(")");
		
		return sb.toString();
	}

	public String getName() {
		return getId(0);
	}

	/**
	 * @return the ith child of id type within the subbrace, starting from zero
	 */
	public String getId(int i) {
		for(DtaElement de: childElements)
		{
			if(de.getType() == Type.ID)
			{
				i--;
				
				if(i < 0) return de.getText();
			}
		}
		
		return null;
	}

	public List<DtaBrace> getSubBraces() {
		return (List<DtaBrace>)(List)getSubElements(Type.BRACE);
	}

	private List<DtaElement> getSubElements(Type type) {
		List<DtaElement> subList = new ArrayList<DtaElement>();
		
		for(DtaElement de: childElements)
		{
			if(de.getType() == type)
				subList.add(de);
		}
				
		return subList;
	}

	public List<String> getIds() {
		List<String> subList = new ArrayList<String>();
		
		for(DtaElement de: childElements)
		{
			if(de.getType() == Type.ID)
			{
				subList.add(de.getText());
			}
		}
		
		return subList;
	}

	public void addData(String data) throws ParseException {
		DtaBrace db = new DbDtaParser(new StringReader(data)).BraceInternal();
		
		childElements.addAll(db.childElements);
	}

	/**
	 * gets the text without the braces
	 */
	public String getInternalText() {
		StringBuffer sb = new StringBuffer();
		
		for(DtaElement de: childElements)
		{
			sb.append(de.getText());
		}
		
		return sb.toString();
	}
	
}
package kr.parser;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

import kr.parser.DtaObject.Status;

public class SongsDtaSong extends DtaObject implements ParseObject
{
	private static final String [] ORIGINAL_SONGS = 
	{
		"addicted",
		"allyouwa",
		"areyouha",
		"babyone",
		"believe",
		"billieje",
		"bizarrel",
		"bornto",
		"brokenw",
		"celebrat",
		"chainof",
		"complica",
		"crawling",
		"cry",
		"dontknow",
		"driftaway",
		"everybre",
		"everymor",
		"everythi",
		"friendsin",
		"geniein",
		"girlsjus",
		"heartbreak",
		"herewith",
		"heyjealo",
		"hitmewit",
		"hotstuff",
		"howyoure",
		"ibelievein",
		"icant",
		"ihate",
		"iheardit",
		"iwill",
		"illbe",
		"illmake",
		"imcoming",
		"imwith",
		"itsmy",
		"endofwor",
		"irresistible",
		"undermy",
		"iwant",
		"jessies",
		"justmy",
		"kissme",
		"ladiesni",
		"ladymarm",
		"letsgetit",
		"likeavir",
		"missyou",
		"mygirl",
		"oneweek",
		"papadont",
		"perfect",
		"pleasemr",
		"redredwi",
		"richgirl",
		"rockandroll",
		"savetoni",
		"scienceg",
		"shetalks",
		"sittingon",
		"smoothcr",
		"preacher",
		"stop",
		"sweethome",
		"firstcut",
		"thejoker",
		"powerofl",
		"thisold",
		"tracksof",
		"toxic",
		"virtual",
		"waiting",
		"wearefam",
		"broken",
		"whenaman",
		"whiteflag",
		"windbene",
		"youreall",
		"yourthe"
	};
	
	private String commentHeader;
	private int songStart=-1;
	private int songEnd=-1;
	private String songName;
	private String currKey;
	private Map<String, String> map = new HashMap<String, String>();
	
	private String entry;

	private int songNameStart=-1;

	private int songNameEnd=-1;

	private boolean parsedSucessfully;

	public SongsDtaSong() {
	}

	public SongsDtaSong(String entry, String songName) {
		this.songName = songName;
		parseItem(entry, 0);
	}

	private void setSongName(String songName) {
		this.songName = songName;
		parseItem(entry, 0);
	}

	protected boolean parsingHook(String text, Status lastStatus, Status currStatus, int index) {
		if(currStatus.mode == Mode.NORMAL) //if transisting off of another status to NORMAL
		{
			if(currStatus.braceLevel == 0 && lastStatus.mode == Mode.COMMENT) //if the comment header for a song
			{
				commentHeader = currStatus.currObject;
				songStart = currStatus.currObjectStart;
			}
			else if(lastStatus.braceLevel == 0 && currStatus.braceLevel == 1 && songStart == -1)//if the song without a comment header
			{
				songStart = index;
			}
			else if(lastStatus.braceLevel == 1 && lastStatus.mode == Mode.WORD)
			{
				if(songName == null)
					songName = currStatus.currObject;
				songNameStart = currStatus.currObjectStart;
				songNameEnd = currStatus.index;
			}
			else if(lastStatus.braceLevel == 2 && lastStatus.mode == Mode.WORD || lastStatus.mode == Mode.QUOTE)
			{
				if(currKey == null)
				{
					currKey = currStatus.currObject;
				}
				else
				{
					map.put(currKey, currStatus.currObject);
				}
			}
			
			//if we've moved from brace level 1 to brace level 2, then reset
			//the key
			if(lastStatus.braceLevel == 1 && currStatus.braceLevel == 2)
				currKey = null;
			
			if(lastStatus.braceLevel == 1 && currStatus.braceLevel == 0)
			{
				songEnd = index+1;
				
				//if the song name was replaced, we need to update it here
				entry = text.substring(songStart, songNameStart)
				+ songName + text.substring(songNameEnd, songEnd);
				
				parsedSucessfully = true;
				return false;
			}
		}
		
		return true;
	}
	
	public String toString()
	{
		return "SongDtaSong(songName="+songName+" songStart="+songStart+" songEnd="+songEnd+")";
	}

	public int getStart() {
		return songStart;
	}

	public int getEnd() {
		return songEnd;
	}

	public String getTitle() {
		return map.get("title");
	}

	public String getName() {
		return songName;
	}

	public boolean parsedSuccessfully() {
		return parsedSucessfully;
	}

	public Object getEntry() {
		return entry;
	}
}

class SongDtaSongTest
{
	public static void main(String []argv) throws IOException
	{
		BufferedReader r;

		if(argv.length != 0)
		{
			r = new BufferedReader(new FileReader(argv[0]));
		}
		else
			r = new BufferedReader(new InputStreamReader(System.in));

		StringBuffer b = new StringBuffer();
		
		int c;
		
		
		String line;
		
		while((line = r.readLine()) != null)
		{
			b.append(line+"\n");
		}
		
		String text = b.toString();
		
		int index = 0;
		
		while(index < text.length())
		{
			SongsDtaSong s = new SongsDtaSong();
			
			index = s.parseItem(text, index);
			System.out.println("song "+s);
			System.out.println("\n"+text.substring(s.getStart(), s.getEnd()));
		}
		
		
	}
}
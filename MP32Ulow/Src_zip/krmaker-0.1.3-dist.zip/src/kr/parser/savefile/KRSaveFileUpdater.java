package kr.parser.savefile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import kr.parser.SongsDtaSong;
import kr.parser.SongsDtaObject;

public class KRSaveFileUpdater {
	
	public static final byte SONG_TYPE = 1;
	
	/**
	 * @return unlockables actually added
	 */
	public static Set<String> updateFileForNewSongs(File f, List<String> songNameList) throws IOException
	{
		return updateFile(f, songNameList, SONG_TYPE);
	}

	/**
	 * @return unlockables actually added
	 */
	public static Set<String> updateFile(File f, List<String> newUnlockables, int type) throws IOException
	{
		if(f.length() != 65556)
			throw new IllegalArgumentException("save file, "+f+", must be exactly 65556 bytes long");
		
		byte [] data = new byte[65556];
		
		InputStream i = new FileInputStream(f);
		
		int c = 0;
		while(c < data.length)
		{
			c = i.read(data, c, data.length - c);
			if(c <= 0)
				throw new IllegalArgumentException("error reading save file, "+f);
		}
		
		i.close();
		
		Set<String> ret = updateFile(data, newUnlockables, type);
		
		OutputStream o = new FileOutputStream(f);
		
		o.write(data);

		o.close();
		
		return ret;
	}
	
	/**
	 * @return unlockables actually added
	 */
	public static Set<String> updateFile(byte [] data, List<String> newUnlockables, int type)
	{
		if(data.length != 65556)
			throw new IllegalArgumentException("save files must be exactly 65556 bytes long");
			
		Set<String> newUnlockablesSet = new HashSet<String>();
		
		for(String u : newUnlockables)
			newUnlockablesSet.add(u);
		
		//first search for the string "party". This marks the start
		//of the second section which is simply a list of what to enable.
		int partyIndex = searchBytes(data, "party".getBytes());
		
		if(partyIndex == -1) throw new IllegalArgumentException("Cannot find 'party' in save file, file may be corrupt...");
		
		
		//the byte 12 previous contains the number of items that are unlocked. we just add to this value.
		//I'm not sure about this, but I'm hoping that it is a word and we can add more than 255 to this
		//value. Let's hope so...
		int countIndex = partyIndex - 12;
		
		int origDataCount = (data[countIndex] & 0xff) + ((data[countIndex+1] & 0xff) << 8);

		//
		//Find all the unlockables we currently have, so that if we already have the ones
		//mentioned we won't specify them twice...
		//
		
		//
		//first, find the end and eliminate duplicated unlockables
		//
		int currIndex = partyIndex + 5;
		
		for(int i = 1; i < origDataCount; i++)
		{
			int dataLength = data[currIndex+4];
			String currUnlockable = new String(data,currIndex + 8, dataLength);
			int currUnlockableType = data[currIndex]; 
			currIndex += 8 + dataLength;
			if(currUnlockableType == type && newUnlockablesSet.contains(currUnlockable))
			{
				newUnlockablesSet.remove(currUnlockable);
			}
		}
		//now currIndex should be at the end of the list, so this is where we insert our new ones
		
		//
		//shift everything down in the save data file
		//
		
		//as a safety check, make sure we have enough room to shift the songs...the save data file
		//contains a constant 65556 bytes, with trailing zeros after the data. To do this
		//we find the first zero in the last string of trailing zeros
		int firstTrailingZero = data.length -1;
		for(firstTrailingZero = data.length -1; firstTrailingZero >= 0; firstTrailingZero--)
		{
			if(data[firstTrailingZero] != 0)
			{
				firstTrailingZero ++;
				break;
			}
		}
		
		//
		// calculate number of bytes to shift
		//
		int newRoomNeeded = newUnlockablesSet.size() * 8;
		
		for(String u : newUnlockablesSet)
		{
			newRoomNeeded += u.length();
		}
		
		if(newRoomNeeded > data.length - firstTrailingZero )
		{
			throw new IllegalArgumentException("Sorry, no room left in save file for additional unlockables, " +
					( data.length - firstTrailingZero) + " bytes available, need " + newRoomNeeded);
		}
		
		//shift the bytes
		System.arraycopy(data, currIndex, data, currIndex + newRoomNeeded, data.length - currIndex - newRoomNeeded);
		
		//
		// update the counter to hold the new unlockables
		//
		if((int)data[countIndex] == -1) // if we will roll over
			data[countIndex+1] += newUnlockablesSet.size(); //update the next byte
		
		data[countIndex] += newUnlockablesSet.size();

		//
		// add our new unlockables
		//
		for(String u: newUnlockablesSet)
		{
			int length = 8 + u.length();
			zero(data,currIndex, length);
			
			data[currIndex] = (byte)type;
			data[currIndex+4] = (byte)(u.length());
			byte [] uData = u.getBytes();
			System.arraycopy(uData, 0, data, currIndex + 8, u.length());
			currIndex += length;
		}
		
		return newUnlockablesSet;
	}

	private static void zero(byte[] data, int currIndex, int length) {
		for(int i = currIndex; i< currIndex + length; i ++)
			data[i] = 0;
	}

	static int searchBytes(byte[] data, byte[] search) {
		int matchedSoFar = 0;
		for(int i = 0; i < data.length; i++)
		{
			if(data[i] == search[matchedSoFar])
			{
				matchedSoFar++;
				if(matchedSoFar == search.length)
					return i + 1 - matchedSoFar;
			}
			else matchedSoFar = 0;
		}
		
		return -1;
	}


	public static void main(String []argv) throws IOException
	{
		if(argv.length <= 1)
		{
			System.err.println("Usage: "+KRSaveFileUpdater.class.getName()+" <save file> <song 1> [song 2] [song 3...] | <save file> <songs.dta file>");
			System.err.println("<save file> must be a kr save file from \"E:\\UDATA\\4b4e0025\\1B208DEA51D3\\KRX\\data\". It will be modified so that KR " +
				"will show the additional songs specified when loaded with the save file. \n" +
				"In order to use it, the KR default.xbe has to be hacked. Do this by using KRDefaultXBEPatcher.bat in windows or krdefaultxbepatcher.sh in linux.");
			System.err.println("<songs.dta file> - this is the songs.dta file from KR with the new songs added to it");
			System.err.println("<song 1> [song 2] [song 3...] - this is a manual list of songs to add, ex. satisfac flagpole cream");
			System.exit(1);
		}
		
		List<String> songList = new ArrayList<String>();

		if(argv[1].matches(".*\\.dta")) // if ends with dta, assume songs.dta
		{
			SongsDtaObject dtaObject = new SongsDtaObject(new File(argv[1]), false);
			for (SongsDtaSong s : dtaObject.getSongs())
			{
				songList.add(s.getName());
			}
		}
		else
		{
			for(int i = 1; i < argv.length; i++)
			{
				songList.add(argv[i]);
			}
		}

		Set<String> unlockablesAdded = KRSaveFileUpdater.updateFileForNewSongs(new File(argv[0]), songList);
		
		for(String s : unlockablesAdded)
		{
			System.out.println("Added "+s);
		}
		
		if(unlockablesAdded.size() == 0)
			System.err.println("No new songs to add");
	}

}

class KRSaveFileParserTest
{
	public static void main(String []argv) throws IOException
	{
		List<String> songList = new ArrayList<String>();
		songList.add("test1");
		songList.add("tes2");
		songList.add("ttttest3");
		songList.add("ttttttttttest4");
		
		KRSaveFileUpdater.updateFileForNewSongs(new File(argv[0]), songList);
	}
}
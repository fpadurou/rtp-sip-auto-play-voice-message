package kr.parser;


/**
 * Abstract parser for *.dta files
 */
public abstract class DtaObject {
	protected enum Mode { COMMENT, NORMAL, WORD, QUOTE };
	
	protected static class Status
	{
		public Mode mode;
		public int braceLevel;
		public int index;
		public String currObject;
		public int currObjectStart;
		
		void copyTo(Status other)
		{
			other.mode = mode;
			other.braceLevel = braceLevel;
			other.index = index;
			other.currObject = currObject;
			other.currObjectStart = currObjectStart;
		}
	}
		
	
	public int parseItem(String text, int index) {
				
		Status currStatus = new Status();
		currStatus.mode = Mode.NORMAL;
		
		Status lastStatus = new Status();
		
		while(index <= text.length()) // one passed the length of the text, so
			//we will transistion from the last character properly
		{
			char c;
			if(index < text.length())
				c = text.charAt(index);
			else c = ' '; //pretend the last character of the text is a space
			
			//copy the current status to the last one before changing it
			currStatus.copyTo(lastStatus);
			
			currStatus.index = index;
			
			if(currStatus.mode == Mode.NORMAL)
			{
				if(c == ';')
				{
					currStatus.mode = Mode.COMMENT;
					currStatus.currObject = String.valueOf(c);
					currStatus.currObjectStart = index;
				}
				else if(c == '(')
				{
					currStatus.braceLevel ++;
				}
				else if(c == ')')
				{
					currStatus.braceLevel --;
				}
				else if(c == '"')
				{
					currStatus.mode = Mode.QUOTE;
					currStatus.currObject = "";
					currStatus.currObjectStart = index+1;
				}
				else if( Character.isLetterOrDigit(c))
				{
					currStatus.mode = Mode.WORD;
					currStatus.currObject = String.valueOf(c);
					currStatus.currObjectStart = index;
				}
				
				index++;
			}//mode == normal
			else if (currStatus.mode == Mode.QUOTE)
			{
				if(c == '"')
				{
					currStatus.mode = Mode.NORMAL;
				}
				else if(c == '\\')
				{
					index++;
					currStatus.currObject += (""+c) + text.charAt(index);
				}
				else
					currStatus.currObject += text.charAt(index);
				
				index++;					
			}//mode == quote
			else if (currStatus.mode == Mode.COMMENT)
			{
				if(c == '\n')
				{
					currStatus.mode = Mode.NORMAL;
				}
				else
					currStatus.currObject += c;
				
				index++;
			}//mode == comment
			else if (currStatus.mode == Mode.WORD)
			{
				if(!Character.isLetterOrDigit(c))
				{
					currStatus.mode = Mode.NORMAL;
					//note that we don't add to index here
					//so that the normal mode can handle this character
				}
				else
				{
					currStatus.currObject += c;
					index++;
				}
			}//mode == comment
			
			if(!parsingHook(text, lastStatus, currStatus, currStatus.index))
				break;
		} //while parsing
		
		return index;
	}
	
	protected abstract boolean parsingHook(String text, Status lastStatus, Status currStatus, int index);

}

package kr.parser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class KRDefaultXBEPatcher {
	public static void main(String [] argv) throws IOException
	{
		if(argv.length != 1 && (argv.length != 2 || argv.length == 2 && !argv[0].equals("-u")))
		{
			System.err.println("Usage: KRDefaultXBEPatcher [-u] <default.xbe from KR>");			
			System.err.println("Patches default.xbe so that new songs can be used with an old kr save file. See KRUnpackager and KRSaveFileUpdater" +
					" for more info");
			System.err.println("[-u] - backs out a patch");
			System.exit(1);
		}
		
		File f;
		boolean undo = false;
		
		if(argv.length == 2)
		{
			undo = true;
			f = new File(argv[1]);
		}
		else
		{
			f = new File(argv[0]);
		}
			
		//check for wierd conditions
		if(!f.exists())
		{
			System.err.println("Error, can't find "+f);
			System.exit(1);
		}

		if(f.length() != 2514944)
		{
			System.err.println("File is not correct size, are you sure this is default.xbe from KR? "+f);
			System.exit(1);
		}

		RandomAccessFile file = new RandomAccessFile(f, "rw");

		//jz to jmp
		file.seek(0x6d9e0);
		file.write(undo ? 0x74 : 0xeb);

		//jz to jmp 2
		file.seek(0x6dcab);
		file.write(undo ? 0x74 : 0xeb);

		file.close();
		
		if(undo)
			System.out.println("'"+f+"' reverted to original.");
		else
			System.out.println("'"+f+"' updated.\nThe kr save data file can now be modified.");
	}
	
}

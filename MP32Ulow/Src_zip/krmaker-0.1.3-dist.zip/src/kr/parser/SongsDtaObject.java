package kr.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import kr.util.Util;

public class SongsDtaObject {

	private boolean sortNewSongsAtEnd;
	
	public static final String [] XBOX_LIVE_SONGS = {
		"babyone",
		"bornto",
		"cry",
		"driftaway",
		"everybre",
		"firstcut",
		"friendsin",
		"geniein",
		"herewith",
		"ibelievein",
		"ihate",
		"illmake",
		"imwith",
		"irresistible",
		"itsmy",
		"iwill",
		"jessies",
		"ladymarm",
		"letsgetit",
		"missyou",
		"mygirl",
		"papadont",
		"perfect",
		"richgirl",
		"rockandroll",
		"sittingon",
		"sweethome",
		"thejoker",
		"toxic",
		"virtual",
		"whiteflag" };

	
	//all songs on the original kr disc, including unlockables and xbox live songs
	public static final String [] ALL_ORIGINAL_SONGS = 
	{
		"addicted",
		"allyouwa",
		"areyouha",
		"babyone",
		"believe",
		"billieje",
		"bizarrel",
		"bornto",
		"brokenw",
		"celebrat",
		"chainof",
		"complica",
		"crawling",
		"cry",
		"dontknow",
		"driftaway",
		"everybre",
		"everymor",
		"everythi",
		"friendsin",
		"geniein",
		"girlsjus",
		"heartbreak",
		"herewith",
		"heyjealo",
		"hitmewit",
		"hotstuff",
		"howyoure",
		"ibelievein",
		"icant",
		"ihate",
		"iheardit",
		"iwill",
		"illbe",
		"illmake",
		"imcoming",
		"imwith",
		"itsmy",
		"endofwor",
		"irresistible",
		"undermy",
		"iwant",
		"jessies",
		"justmy",
		"kissme",
		"ladiesni",
		"ladymarm",
		"letsgetit",
		"likeavir",
		"missyou",
		"mygirl",
		"oneweek",
		"papadont",
		"perfect",
		"pleasemr",
		"redredwi",
		"richgirl",
		"rockandroll",
		"savetoni",
		"scienceg",
		"shetalks",
		"sittingon",
		"smoothcr",
		"preacher",
		"stop",
		"sweethome",
		"firstcut",
		"thejoker",
		"powerofl",
		"thisold",
		"tracksof",
		"toxic",
		"virtual",
		"waiting",
		"wearefam",
		"broken",
		"whenaman",
		"whiteflag",
		"windbene",
		"youreall",
		"yourthe"
	};
	

	
	//PERF: use a set, but what kind of performance problems will we have with this?
	private List<SongsDtaSong> songs = new ArrayList<SongsDtaSong>(); 

	public SongsDtaObject(String songsDtaText, boolean sortNewSongsAtEnd) {
		init(songsDtaText, sortNewSongsAtEnd);
	}
	
	public SongsDtaObject(File file, boolean sortNewSongsAtEnd) throws IOException {
		FileInputStream is = new FileInputStream(file);
		String text = Util.readText(is);
		is.close();
		
		init(text, sortNewSongsAtEnd);
	}

	private void init(String songsDtaText, boolean sortNewSongsAtEnd)
	{
		this.sortNewSongsAtEnd = sortNewSongsAtEnd;
		
		int index = 0;
		
		while(index < songsDtaText.length())
		{
			SongsDtaSong song = new SongsDtaSong();
			index = song.parseItem(songsDtaText, index);
			if(song.parsedSuccessfully())
				songs.add(song);
		}
	}

	public void addSong(String entry, String songName, boolean overwrite) {
		SongsDtaSong song = new SongsDtaSong(entry, songName);
		
		//check for duplicates
		for(SongsDtaSong other : songs)
		{
			if(other.getName().equals(song.getName()))
			{
				if(overwrite) //if overwrite, remove the old and add the new
				{
					songs.remove(other);
					songs.add(song);
				}
				
				return;
			}
		}
		
		songs.add(song);
	}

	public String createText() {
		//
		// sort considering "sortNewSongsAtEnd"
		//
		SongNameComparator c = new SongNameComparator();
		if(sortNewSongsAtEnd)
			c.sortAtStart(Arrays.asList(ALL_ORIGINAL_SONGS));
		
		
		Collections.sort(songs, c);
				
		StringBuffer sb = new StringBuffer();
		
		for(SongsDtaSong s : songs)
		{
			sb.append(s.getEntry()).append("\n").append("\n");
		}
		
		//make sure each line has a "\r\n" at the end
		return sb.toString().replace("\r", "").replace("\n", "\r\n");
	}

	private static class SongNameComparator implements Comparator<SongsDtaSong>
	{
		private List<String> alreadySortedList = new ArrayList<String>();

		public SongNameComparator() {
		}

		public void sortAtStart(List<String> alreadySortedList) {
			this.alreadySortedList = alreadySortedList;
		}

		public int compare(SongsDtaSong o1, SongsDtaSong o2) {
			int alreadySortedIndex1 = alreadySortedList.indexOf(o1.getName());
			int alreadySortedIndex2 = alreadySortedList.indexOf(o2.getName());
			
			if(alreadySortedIndex1 == -1)
				alreadySortedIndex1 = alreadySortedList.size()+1;
			if(alreadySortedIndex2 == -1)
				alreadySortedIndex2 = alreadySortedList.size()+1;
			
			if(alreadySortedIndex1 != alreadySortedIndex2) return alreadySortedIndex1 - alreadySortedIndex2;
			
			//compare the titles using only alphabetical chars, numbers, and spaces.
			return o1.getTitle().replaceAll("[^a-zA-Z0-9 ]","").compareTo(o2.getTitle().replaceAll("[^a-zA-Z0-9 ]",""));
		}
	}

	public Collection<SongsDtaSong> getSongs() {
		return songs;
	}
}

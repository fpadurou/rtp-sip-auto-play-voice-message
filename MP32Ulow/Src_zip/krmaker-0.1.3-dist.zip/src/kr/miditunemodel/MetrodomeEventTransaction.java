package kr.miditunemodel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import kr.miditunemodel.MidiTuneModel.MessageType;
import kr.undo.Operation;
import kr.undo.Transaction;

/**
 * A Transaction of operations involving midi notes
 */
public class MetrodomeEventTransaction extends MidiTransaction<KREvent>
{
	public MetrodomeEventTransaction(MidiTuneModel midiTuneModel)
	{
		super(midiTuneModel.getMetrodomeEventGroup());
	}
	
	public boolean doIt()
	{
		if(super.doIt())
		{
			eventGroup.reseat(getEvents());
			return true;
		}
		
		return false;
	}
}

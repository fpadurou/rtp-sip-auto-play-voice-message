package kr.miditunemodel;

import kr.miditunemodel.NoteEventGuiModel.MessageType;
import kr.util.ListenerManager;
import kr.util.audio.AudioClip;
import kr.util.audio.MidiAudioClip;

public class KREventGuiModel extends EventGuiModel<KREvent>
{
	public enum MessageType {TEXT_UPDATED };

	public KREventGuiModel(MidiTuneModel midiTuneModel) {
		super(midiTuneModel.getKREventGroup());
	}

	public void updateType(KREvent e, KREvent.Type type)
	{
		e.setKRType(type);
		ListenerManager.inst().notify(this, MessageType.TEXT_UPDATED);
	}


}

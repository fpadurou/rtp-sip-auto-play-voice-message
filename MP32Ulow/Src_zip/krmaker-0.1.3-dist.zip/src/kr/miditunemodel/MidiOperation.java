package kr.miditunemodel;

import kr.undo.Operation;


public abstract class MidiOperation<T extends Event> implements Operation
{
	
	protected T event;

	public MidiOperation(T event)
	{
		this.event = event;
	}

	public MidiOperation()
	{
	}

	public T getEvent() {
		return event;
	}
}

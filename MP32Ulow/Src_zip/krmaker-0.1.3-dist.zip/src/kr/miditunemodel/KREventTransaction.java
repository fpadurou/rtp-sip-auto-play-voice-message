package kr.miditunemodel;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import kr.miditunemodel.MidiTuneModel.MessageType;
import kr.undo.Operation;
import kr.undo.Transaction;

/**
 * A Transaction of operations involving midi notes
 */
public class KREventTransaction extends MidiTransaction<KREvent>
{
	public KREventTransaction(MidiTuneModel midiTuneModel)
	{
		super(midiTuneModel.getKREventGroup());
	}
	
	public boolean doIt()
	{
		if(super.doIt())
		{
			eventGroup.reseat(getEvents());
			return true;
		}
		
		return false;
	}
}

//package kr.util;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import javax.media.Codec;
//import javax.sound.sampled.AudioInputStream;
//
//
//public class AudioInputStreamJMFCodecAdaptor extends AudioInputStream {
//	private AudioInputStream source;
//	private List<Codec> codecs = new ArrayList<Codec>();
//	
//	
//
//	public void setSource(AudioInputStream in) {
//		source = in;
//	}
//
//	public void addCodec(Codec codec) {
//		codecs.add(codec);
//	}
//
//}

package kr.util.sample;

import kr.util.audio.AudioClip;

public class KaraokeSplitter 
{
	private AudioClip input;
	private AudioClip vocalsOut;
	private AudioClip bkgOut;


	public KaraokeSplitter()
	{
		float v = .5f;
	}
	
	public void setInputClip(AudioClip ac)
	{
		this.input = ac;
	}
	
	public AudioClip getVocalsOut()
	{
		return vocalsOut;
	}

	
	public AudioClip getBkgOut()
	{
		return bkgOut;
	}

}

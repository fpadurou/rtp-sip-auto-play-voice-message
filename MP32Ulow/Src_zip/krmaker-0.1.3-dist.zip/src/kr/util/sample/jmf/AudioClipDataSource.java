//package kr.util.sample.jmf;
//
//import java.io.IOException;
//
//import javax.media.Duration;
//import javax.media.Time;
//import javax.media.protocol.ContentDescriptor;
//import javax.media.protocol.DataSource;
//import javax.media.protocol.PullDataSource;
//import javax.media.protocol.PullSourceStream;
//import javax.media.protocol.Seekable;
//
//import kr.util.audio.AudioClip;
//
//public class AudioClipDataSource extends PullDataSource {
//	private AudioClip in;
//
//	private AudioClipPullSourceStream stream;
//
//	public AudioClipDataSource(AudioClip in) {
//		this.in = in;
//		stream = new AudioClipPullSourceStream();
//	}
//
//	public String getContentType() {
//		return "audio.x_wav"; // TODO: what should this really be?
//	}
//
//	public void connect() throws IOException {
//	}
//
//	public void disconnect() {
//	}
//
//	public void start() throws IOException {
//	}
//
//	public void stop() throws IOException {
//	}
//
//	public PullSourceStream[] getStreams() {
//		return new PullSourceStream[] { stream };
//	}
//
//	public Time getDuration() {
//		return Duration.DURATION_UNKNOWN;
//	}
//
//	public Object[] getControls() {
//		return new Object[0];
//
//	}
//
//	public Object getControl(String controlType) {
//		return null;
//	}
//
//	class AudioClipPullSourceStream implements PullSourceStream, Seekable {
//		int pos;
//
//		public boolean willReadBlock() {
//			return false;
//		}
//
//		public int read(byte[] buffer, int offset, int length) {
//			in.copyTo(pos, length, buffer, offset);
//			pos += length;
//			
//			return length;
//		}
//
//		// TODO
//		public ContentDescriptor getContentDescriptor() {
//			// System.out.println("in getContentDescriptor"); // TODO
//			return null;
//		}
//
//		public long getContentLength() {
//			return in.length();
//		}
//
//		public boolean endOfStream() {
//			return false; // TODO
//		}
//
//		public Object[] getControls() {
//			return new Object[0];
//		}
//
//		public Object getControl(String controlType) {
//			return null;
//		}
//
//		public long seek(long where) {
//			return pos = (int)where;
//		}
//
//		public long tell() {
//			return pos;
//		}
//
//		public boolean isRandomAccess() {
//			return true;
//		}
//
//	}
//
//}

//package kr.util.sample.jmf;
//
//import java.io.IOException;
//import java.util.Enumeration;
//import java.util.Vector;
//
//import javax.media.Buffer;
//import javax.media.DataSink;
//import javax.media.IncompatibleSourceException;
//import javax.media.MediaLocator;
//import javax.media.Time;
//import javax.media.datasink.DataSinkErrorEvent;
//import javax.media.datasink.DataSinkEvent;
//import javax.media.datasink.DataSinkListener;
//import javax.media.datasink.EndOfStreamEvent;
//import javax.media.protocol.BufferTransferHandler;
//import javax.media.protocol.DataSource;
//import javax.media.protocol.PullDataSource;
//import javax.media.protocol.PushBufferDataSource;
//import javax.media.protocol.PushBufferStream;
//import javax.media.protocol.PushDataSource;
//import javax.media.protocol.PushSourceStream;
//import javax.media.protocol.SourceStream;
//import javax.media.protocol.SourceTransferHandler;
//
//import kr.util.audio.AudioClip;
//import kr.util.audio.WritableAudioClip;
//
//public class ByteDataDataSink implements DataSink, SourceTransferHandler, BufferTransferHandler
//{
//	private WritableAudioClip byteData;
//
//	private Vector listeners = new Vector(1);
//
//	private DataSource source;
//
//	private boolean push;
//	private SourceStream stream;
//
//	private String contentType;
//	
//	private byte [] tempBuffer = new byte[2048];
//
//	private DataSourceType dataSourceType;
//	
//	private enum DataSourceType { PUSH, PUSH_BUFFER};
//	
//
//	public ByteDataDataSink(WritableAudioClip byteData) {
//		this.byteData = byteData;
//	}
//
//	public void setSource(DataSource ds) throws IncompatibleSourceException {
//
//		if (ds instanceof PushDataSource)
//		{
//			setPushDataSource((PushDataSource)ds);
//		}
//		else if (ds instanceof PushBufferDataSource)
//		{
//			setPushBufferDataSource((PushBufferDataSource)ds);
//		}
//		else
//			throw new IncompatibleSourceException("Incompatible datasource");
//	}
//	
//	public void setPushBufferDataSource(PushBufferDataSource ds) throws IncompatibleSourceException
//	{
//		source = ds;
//				
//		SourceStream [] streams;
//
//		dataSourceType = DataSourceType.PUSH;
//		try {
//			ds.connect();
//		} catch (IOException ioe) {
//			ioe.printStackTrace();
//		}
//		
//		streams = ds.getStreams();
//
//		if (streams == null || streams.length != 1)
//			throw new IncompatibleSourceException(
//					"DataSource should have 1 stream");
//		stream = streams[0];
//
//		contentType = source.getContentType();
//		((PushBufferStream) stream).setTransferHandler(this);
//	}
//
//	public void setPushDataSource(PushDataSource ds) throws IncompatibleSourceException
//	{
//		source = ds;
//		
//		SourceStream [] streams;
//
//		dataSourceType = DataSourceType.PUSH;
//		try {
//			((PushDataSource) source).connect();
//		} catch (IOException ioe) {
//			ioe.printStackTrace();
//		}
//		
//		streams = ds.getStreams();
//
//		if (streams == null || streams.length != 1)
//			throw new IncompatibleSourceException(
//					"DataSource should have 1 stream");
//		stream = streams[0];
//
//		contentType = source.getContentType();
//		((PushSourceStream) stream).setTransferHandler(this);
//	}
//
//	public void setOutputLocator(MediaLocator output) {
//	}
//
//	public MediaLocator getOutputLocator() {
//		return null;
//	}
//
//	public void start() throws IOException {
//		source.start();
//	}
//
//	public void stop() throws IOException {
//	}
//
//	public void open() throws IOException, SecurityException {
//	}
//
//	public void close() {
//	}
//
//	public String getContentType() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public Object[] getControls() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public Object getControl(String controlType) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public void addDataSinkListener(DataSinkListener dsl) {
//		if (dsl != null)
//			if (!listeners.contains(dsl))
//				listeners.addElement(dsl);
//	}
//
//	public void removeDataSinkListener(DataSinkListener dsl) {
//		if (dsl != null)
//			listeners.removeElement(dsl);
//	}
//
//	private void sendEvent(DataSinkEvent event) {
//		if (!listeners.isEmpty()) {
//			synchronized (listeners) {
//				Enumeration list = listeners.elements();
//				while (list.hasMoreElements()) {
//					DataSinkListener listener = (DataSinkListener) list
//							.nextElement();
//					listener.dataSinkUpdate(event);
//				}
//			}
//		}
//	}
//
//	private void removeAllListeners() {
//		listeners.removeAllElements();
//	}
//
//	private final void sendEndofStreamEvent() {
//		sendEvent(new EndOfStreamEvent(this));
//	}
//
//	private final void sendDataSinkErrorEvent(String reason) {
//		sendEvent(new DataSinkErrorEvent(this, reason));
//	}
//
//    public void transferData(PushSourceStream pss) {
//    	int totalRead = 0;
//		int bytesRead;
//
//		while (true)
//    	{
//			try {
//				bytesRead = pss.read(tempBuffer, totalRead, tempBuffer.length - totalRead);
//			} catch (IOException e) {
//				return;
//			}
//
//    		if (bytesRead <= 0)
//    			break;    	    
//    		totalRead+=bytesRead;
//    	}
//	
//    	byteData.append(tempBuffer,0, totalRead);
//    	
//    	if(bytesRead == -1)
//    		sendEndofStreamEvent();
//    }
//    
//    private Buffer buffer = new Buffer();
//
//	public void transferData(PushBufferStream pss) {
//		try {
//			pss.read(buffer);
//		} catch (IOException e) {
//			e.printStackTrace();
//			return;
//		}
//		
//		if(buffer.isDiscard()) return;
//		
//		byteData.append((byte [])buffer.getData());
//		
//		if(buffer.isEOM())	
//    		sendEndofStreamEvent();
//	}
//
//}

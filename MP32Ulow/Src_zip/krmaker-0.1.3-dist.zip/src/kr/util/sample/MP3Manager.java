package kr.util.sample;

import java.io.File;

import kr.util.audio.AudioClip;

public class MP3Manager {

	public AudioClip getMP3Data(File sampleFile) {
		// TODO Auto-generated method stub
		return null;
	}

}

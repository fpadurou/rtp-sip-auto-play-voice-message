package kr.util;

public interface Listener
{
	public void notify(Object source, Object type, Object... values);
}

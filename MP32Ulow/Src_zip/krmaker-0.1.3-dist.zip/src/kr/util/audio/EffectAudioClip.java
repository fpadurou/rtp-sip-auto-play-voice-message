package kr.util.audio;

public abstract class EffectAudioClip extends AudioClip {
	protected AudioClip source;
	
	public AudioClip getSource() {
		return source;
	}

	public void setSource(AudioClip source) {
		this.source = source;
	}
}

package kr.util.audio;


public abstract class WritableAudioClip extends AudioClip
{
	public void append(byte[] data) { 
		append(data, 0, data.length);
	}

	
	public abstract void copyFrom(int offset, int length, byte[] src, int srcOffset);

	public abstract void append(byte[] data, int offset, int length);

	public abstract void ensureCapacityInFrames(long frameLength);

}

package kr.undo;

public interface Operation {

	void undo();

	void doIt();
	
	boolean isValid();
}

package kr.undo;


public class UndoLog 
{
//	private static final int MAX_UNDO_SIZE = 100;
//
//	private Transaction tran;
//	
//	private BoundedLinkedList<Transaction> transList = new BoundedLinkedList<Transaction>(MAX_UNDO_SIZE); 
//	
//	public UndoLog()
//	{
//	}
//	
//	public Transaction startTransaction()
//	{
//		tran = new Transaction();
//		transList.add(tran);
//		return tran;
//	}
}

package kr;

/**
 * Used to keep several time dependent things in sync.
 */
public interface TimeKeeper {
	public long getCurrMicros();
}

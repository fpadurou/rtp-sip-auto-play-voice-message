import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;

public class WavPlayer {
	public static void main(String [] args) throws Exception
	{
		AudioClip a = Applet.newAudioClip(new File(args[0]).toURL());
		a.play();
	}
}
